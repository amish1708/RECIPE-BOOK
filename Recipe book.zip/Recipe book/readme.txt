==============================
📚 My Recipe Book - README.txt
==============================

This project demonstrates my front-end web development skills using **HTML**, **CSS**, and **JavaScript**.
It's a simple recipe book web app where you can **add**, **search**, and **view** delicious vegetarian recipes,
and it also includes a dummy contact form.

──────────────────────────────
1️⃣ HTML (index.html)
──────────────────────────────

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Recipe Book</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <style>

:root {
  --bg: #fffdf7; /* Soft Cream */
  --card: #ffffff; /* Pure White */
  --accent: #077a6e; /* Fresh Mint */
  --highlight: #f9d5a7; /* Light Peach */
  --cta: #ff6b6b; /* Warm Coral */
  --text: #2c2c2c; /* Charcoal */
  --shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  --radius: 12px;
}

*,
*::before,
*::after {
  box-sizing: border-box;
}

body {
  font-family: Arial, sans-serif;
  background: var(--bg);
  color: var(--text);
  margin: 0;
  padding: 20px;
  line-height: 1.6;
}

.hero {
  position: relative;
  background: url("https://source.unsplash.com/1600x400/?food,kitchen")
    center/cover no-repeat;
  height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
}

.hero::before {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--accent); /* semi-transparent dark overlay */
}

.hero-overlay {
  position: relative;
  color: #fff;
  z-index: 1;
}

.hero h1 {
  font-size: 3rem;
  margin: 0 0 10px;
  text-shadow: 2px 2px 6px #000;
}

.hero p {
  font-size: 1.2rem;
  text-shadow: 1px 1px 4px #000;
}

main {
  max-width: 1200px;
  margin: 0 auto;
}

.add-recipe {
  background: var(--card);
  padding: 20px;
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  margin: 30px auto;
}

.add-recipe h2 {
  margin-top: 0;
  color: var(--accent);
}

#recipeForm input[type="text"],
#recipeForm textarea,
#recipeForm input[type="file"] {
  width: 100%;
  padding: 12px;
  margin: 10px 0;
  border: 1px solid var(--accent);
  border-radius: var(--radius);
  font-size: 1rem;
}

#recipeForm textarea {
  resize: vertical;
  min-height: 80px;
}

#recipeForm button {
  background: var(--cta);
  color: #fff;
  border: none;
  padding: 12px 25px;
  border-radius: var(--radius);
  cursor: pointer;
  font-size: 1rem;
  transition: background 0.3s ease;
}

#recipeForm button:hover {
  background: #cb0b0b;
}

.search-section {
  text-align: center;
  margin: 30px 0;
}

#searchInput {
  width: 90%;
  max-width: 400px;
  padding: 12px;
  border: 2px solid var(--accent);
  border-radius: var(--radius);
  font-size: 1rem;
}

.recipes-section {
  margin: 40px 0;
}

.recipes-section h2 {
  text-align: center;
  color: var(--accent);
}

.recipes-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
}

.recipe-card {
  background: var(--card);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  overflow: hidden;
  transition: transform 0.3s, box-shadow 0.3s;
}

.recipe-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 18px rgba(0, 0, 0, 0.15);
}

.recipe-card img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.recipe-card .content {
  padding: 15px;
}

.recipe-card h3 {
  margin: 0 0 10px;
  color: var(--accent);
}

.recipe-card button {
  display: inline-block;
  padding: 8px 16px;
  background: var(--accent);
  color: #fff;
  border: none;
  border-radius: var(--radius);
  cursor: pointer;
  font-size: 0.9rem;
  transition: background 0.3s ease;
}

.recipe-card button:hover {
  background: #055d53;
}

.modal {
  display: none;
  position: fixed;
  z-index: 10;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background: rgba(0, 0, 0, 0.6);
}

.modal-content {
  background: var(--card);
  margin: 5% auto;
  padding: 20px;
  border-radius: var(--radius);
  max-width: 90%;
  width: 500px;
  box-shadow: var(--shadow);
  position: relative;
  animation: fadeIn 0.3s ease;
}

.modal-content img {
  width: 100%;
  height: auto;
  border-radius: var(--radius);
  margin-bottom: 15px;
}

.modal-content h3 {
  margin-top: 15px;
  color: var(--accent);
}

.modal-content p {
  margin-bottom: 10px;
}

.close {
  color: var(--cta);
  position: absolute;
  right: 20px;
  top: 10px;
  font-size: 28px;
  font-weight: bold;
  cursor: pointer;
}

footer {
  background: var(--accent);
  color: #fff;
  text-align: center;
  padding: 20px 10px;
  margin-top: 50px;
}

.footer-content p {
  margin: 20px 0;
  font-size: 0.9rem;
}

footer a {
  color: #fff;
  text-decoration: underline;
}

footer a:hover {
  text-decoration: none;
}

footer form {
  margin-top: 20px;
  background: var(--card);
  padding: 20px;
  border-radius: var(--radius);
  max-width: 400px;
  margin-left: auto;
  margin-right: auto;
  box-shadow: var(--shadow);
}

footer form h3 {
  margin-top: 0;
  margin-bottom: 10px;
  color: var(--accent);
}

footer form input,
footer form textarea {
  width: 100%;
  padding: 10px;
  margin: 8px 0;
  border: 1px solid var(--accent);
  border-radius: var(--radius);
  font-size: 1rem;
}

footer form textarea {
  min-height: 80px;
  resize: vertical;
}

footer form button {
  background: var(--cta);
  color: #fff;
  border: none;
  padding: 10px 20px;
  border-radius: var(--radius);
  cursor: pointer;
  font-size: 1rem;
  transition: background 0.3s ease;
}

footer form button:hover {
  background: #e61b1b;
}

/* Animations */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Responsiveness */
@media (max-width: 768px) {
  .hero h1 {
    font-size: 2rem;
  }
  .hero p {
    font-size: 1rem;
  }
}

@media (max-width: 480px) {
  .hero h1 {
    font-size: 1.5rem;
  }
  .recipe-card img {
    height: 140px;
  }
  .modal-content {
    width: 95%;
    margin-top: 20%;
  }
}
   </style>

  </head>
  <body>
    <header class="hero">
      <div class="hero-overlay">
        <h1>🧑‍🍳 My Recipe Book</h1>
        <p>Discover, Cook & Share Delicious Veg Recipes</p>
      </div>
    </header>

    <main>
      <!-- Recipe Form -->
      <section class="add-recipe">
        <h2>Add New Recipe</h2>
        <form id="recipeForm">
          <input type="text" id="name" placeholder="Recipe Name" required />
          <textarea
            id="ingredients"
            placeholder="Ingredients (comma separated)"
            required
          ></textarea>
          <textarea
            id="steps"
            placeholder="Preparation Steps"
            required
          ></textarea>
          <input type="file" id="image" accept="image/*" required />
          <button type="submit">Add Recipe</button>
        </form>
      </section>

      <!-- Search Bar -->
      <section class="search-section">
        <input
          type="text"
          id="searchInput"
          placeholder="🔍 Search recipes by name or ingredients..."
        />
      </section>

      <!-- container for recipe cards -->
      <section class="recipes-section">
        <h2>All Recipes</h2>
        <div id="recipesList" class="recipes-grid"></div>
      </section>
    </main>

    <!--  Modal for View Details -->
    <div id="modal" class="modal">
      <div class="modal-content">
        <span id="closeModal" class="close">&times;</span>
        <h2 id="modalName"></h2>
        <img id="modalImage" src="" alt="" />
        <h3>Ingredients</h3>
        <p id="modalIngredients"></p>
        <h3>Steps</h3>
        <p id="modalSteps"></p>
      </div>
    </div>
    <!--  Footer -->
    <footer>
      <div class="footer-content">
        <form id="contactForm">
          <h3>Contact Me</h3>
          <input type="text" placeholder="Your Name" required />
          <input type="email" placeholder="Your Email" required />
          <textarea placeholder="Your Message"></textarea>
          <button type="submit">Send</button>
        </form>

        <p>🍲 My Recipe Book — Created with love for Food Lovers</p>
        <p>&copy; 2025 Your Name. All rights reserved.</p>
      </div>
    </footer>

    <script>
    // Get elements
const recipeForm = document.getElementById("recipeForm");
const recipesList = document.getElementById("recipesList");
const modal = document.getElementById("modal");
const closeModal = document.getElementById("closeModal");
const modalName = document.getElementById("modalName");
const modalImage = document.getElementById("modalImage");
const modalIngredients = document.getElementById("modalIngredients");
const modalSteps = document.getElementById("modalSteps");
const searchInput = document.getElementById("searchInput");

// default recipes
const defaultRecipes = [
  {
    name: "Classic Spaghetti",
    ingredients: ["Spaghetti", "Tomato Sauce", "Garlic", "Olive Oil", "Basil"],
    steps: "Boil pasta, cook sauce, mix together and serve hot.",
    image: "images/Classic Spaghetti.jpg",
  },
  {
    name: "Fresh Salad Bowl",
    ingredients: ["Lettuce", "Tomatoes", "Cucumber", "Carrots", "Vinaigrette"],
    steps: "Chop veggies, toss with dressing, enjoy fresh.",
    image: "images/Fresh Salad Bowl.jpg",
  },
  {
    name: "Homemade Pancakes",
    ingredients: ["Flour", "Eggs", "Milk", "Sugar", "Butter"],
    steps: "Mix batter, pour on pan, flip and serve with syrup.",
    image: "images/Homemade Pancakes.jpg",
  },
  {
    name: "Veggie Stir Fry",
    ingredients: ["Broccoli", "Bell Peppers", "Carrots", "Soy Sauce", "Garlic"],
    steps: "Stir fry veggies in a wok with soy sauce and garlic.",
    image: "images/Veggie Stir Fry.jpg",
  },
  {
    name: "Mushroom Risotto",
    ingredients: [
      "Arborio Rice",
      "Mushrooms",
      "Onion",
      "Vegetable Broth",
      "Parmesan",
    ],
    steps:
      "Cook rice slowly with broth, add sautéed mushrooms, top with cheese.",
    image: "images/Mushroom Risotto.jpg",
  },
  {
    name: "Caprese Sandwich",
    ingredients: ["Bread", "Tomatoes", "Mozzarella", "Basil", "Balsamic Glaze"],
    steps: "Layer tomatoes, mozzarella, basil; drizzle with balsamic glaze.",
    image: "images/Caprese Sandwich.jpg",
  },
  {
    name: "Veggie Pizza",
    ingredients: [
      "Pizza Dough",
      "Tomato Sauce",
      "Bell Peppers",
      "Onions",
      "Mozzarella",
    ],
    steps: "Top dough with sauce, veggies, cheese; bake until golden.",
    image: "images/Veggie Pizza.jpg",
  },
  {
    name: "Greek Salad",
    ingredients: ["Cucumber", "Tomatoes", "Feta Cheese", "Olives", "Olive Oil"],
    steps: "Combine chopped veggies, olives, feta; drizzle with olive oil.",
    image: "images/Greek Salad.jpg",
  },
  {
    name: "Vegetable Soup",
    ingredients: ["Carrots", "Potatoes", "Celery", "Tomatoes", "Herbs"],
    steps: "Simmer all veggies in broth with herbs until tender.",
    image: "images/Vegetable Soup.jpg",
  },
  {
    name: "Stuffed Bell Peppers",
    ingredients: ["Bell Peppers", "Rice", "Tomatoes", "Onions", "Cheese"],
    steps: "Stuff peppers with cooked rice mixture, bake with cheese topping.",
    image: "images/Stuffed Bell Peppers.jpg",
  },
  {
    name: "Chickpea Salad",
    ingredients: [
      "Chickpeas",
      "Cucumber",
      "Tomatoes",
      "Red Onion",
      "Lemon Juice",
    ],
    steps: "Mix chickpeas with chopped veggies, dress with lemon juice.",
    image: "images/Chickpea Salad.jpg",
  },
  {
    name: "Paneer Tikka",
    ingredients: ["Paneer", "Bell Peppers", "Yogurt", "Spices", "Onion"],
    steps: "Marinate paneer and veggies in spiced yogurt, grill until charred.",
    image: "images/Paneer Tikka.jpg",
  },
  {
    name: "Aloo Paratha",
    ingredients: ["Whole Wheat Flour", "Potatoes", "Spices", "Butter"],
    steps: "Stuff dough with spiced mashed potatoes, roll and cook on a pan.",
    image: "images/Aloo Paratha.jpg",
  },
  {
    name: "Vegetable Biryani",
    ingredients: [
      "Basmati Rice",
      "Mixed Vegetables",
      "Spices",
      "Yogurt",
      "Onion",
    ],
    steps: "Layer cooked veggies and rice with spices, steam until aromatic.",
    image: "images/Vegetable Biryani.jpg",
  },
  {
    name: "Dhokla",
    ingredients: [
      "Gram Flour",
      "Yogurt",
      "Spices",
      "Mustard Seeds",
      "Coriander",
    ],
    steps:
      "Steam spiced batter, temper with mustard seeds, garnish with coriander.",
    image: "images/Dhokla.jpg",
  },
  {
    name: "Veg Sandwich",
    ingredients: ["Bread", "Cucumber", "Tomatoes", "Onion", "Green Chutney"],
    steps: "Layer sliced veggies and chutney between bread slices.",
    image: "images/Veg Sandwich.jpg",
  },
  {
    name: "Hummus Wrap",
    ingredients: ["Tortilla", "Hummus", "Lettuce", "Cucumber", "Carrots"],
    steps: "Spread hummus on wrap, fill with veggies, roll tightly.",
    image: "images/Hummus Wrap.jpg",
  },
  {
    name: "Veggie Burger",
    ingredients: ["Burger Bun", "Veggie Patty", "Lettuce", "Tomato", "Cheese"],
    steps: "Grill patty, assemble burger with toppings.",
    image: "images/Veggie Burger.jpg",
  },
  {
    name: "Matar Paneer",
    ingredients: ["Paneer", "Green Peas", "Tomatoes", "Onion", "Spices"],
    steps: "Cook paneer and peas in spiced tomato-onion gravy.",
    image: "images/Matar Paneer.jpg",
  },
  {
    name: "Veg Fried Rice",
    ingredients: ["Rice", "Mixed Vegetables", "Soy Sauce", "Ginger", "Garlic"],
    steps: "Stir-fry cooked rice with veggies, ginger, garlic, and soy sauce.",
    image: "images/Veg Fried Rice.jpg",
  },
];

// ✅ Load from localStorage or use default
let recipes = [];
try {
  recipes = JSON.parse(localStorage.getItem("recipes")) || [];
} catch (err) {
  recipes = [];
}

if (!recipes || recipes.length === 0) {
  recipes = [...defaultRecipes];
  localStorage.setItem("recipes", JSON.stringify(recipes));
}

// ✅ Save helper
function saveRecipes() {
  localStorage.setItem("recipes", JSON.stringify(recipes));
}

// ✅ Form submit
recipeForm.addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const ingredients = document.getElementById("ingredients").value.trim();
  const steps = document.getElementById("steps").value.trim();
  const imageInput = document.getElementById("image");
  const imageFile = imageInput.files[0];

  if (!name || !ingredients || !steps || !imageFile) {
    alert("Please fill in all fields and select an image.");
    return;
  }

  const reader = new FileReader();
  reader.onload = function () {
    const imageURL = reader.result;

    const newRecipe = {
      name,
      ingredients: ingredients.split(",").map((ing) => ing.trim()),
      steps,
      image: imageURL,
    };

    recipes.push(newRecipe);
    saveRecipes();
    displayRecipes();
    recipeForm.reset();
  };
  reader.readAsDataURL(imageFile);
});

// ✅ Display recipes
function displayRecipes(list = recipes) {
  recipesList.innerHTML = "";
  list.forEach((recipe, index) => {
    const card = document.createElement("div");
    card.className = "recipe-card";
    card.innerHTML = `
      <img src="${recipe.image}" alt="${recipe.name}" />
      <div class="content">
        <h3>${recipe.name}</h3>
        <button data-index="${index}" class="details-btn">View Details</button>
      </div>
    `;
    recipesList.appendChild(card);
  });

  document.querySelectorAll(".details-btn").forEach((btn) => {
    btn.addEventListener("click", function () {
      const index = this.getAttribute("data-index");
      showModal(index);
    });
  });
}

// ✅ Show modal
function showModal(index) {
  const recipe = recipes[index];
  modalName.textContent = recipe.name;
  modalImage.src = recipe.image;
  modalIngredients.textContent = recipe.ingredients.join(", ");
  modalSteps.textContent = recipe.steps;
  modal.style.display = "block";
}

closeModal.onclick = () => (modal.style.display = "none");
window.onclick = (e) => {
  if (e.target === modal) modal.style.display = "none";
};

// ✅ Search
searchInput.addEventListener("input", function () {
  const query = this.value.toLowerCase();
  recipesList.innerHTML = "";

  recipes
    .filter(
      (recipe) =>
        recipe.name.toLowerCase().includes(query) ||
        recipe.ingredients.join(", ").toLowerCase().includes(query)
    )
    .forEach((recipe) => {
      const indexInFullArray = recipes.indexOf(recipe);

      const card = document.createElement("div");
      card.className = "recipe-card";

      card.innerHTML = `
        <img src="${recipe.image}" alt="${recipe.name}" />
        <div class="content">
          <h3>${recipe.name}</h3>
          <button onclick="showModal(${indexInFullArray})">View Details</button>
        </div>
      `;

      recipesList.appendChild(card);
    });
});

// ✅ Contact form dummy
document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Thank you! Your message has been received.");
  this.reset();
});

// ✅ Display all
displayRecipes();

    </script>
  </body>
</html>
